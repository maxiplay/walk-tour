"""The tests for Device tracker platforms."""
