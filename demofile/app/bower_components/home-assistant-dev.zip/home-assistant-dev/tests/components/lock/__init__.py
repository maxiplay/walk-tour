"""The tests for Lock platforms."""
