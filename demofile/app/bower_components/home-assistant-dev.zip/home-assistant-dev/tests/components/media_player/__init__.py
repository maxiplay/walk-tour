"""The tests for Media player platforms."""
