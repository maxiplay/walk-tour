"""The tests for Sensor platforms."""
