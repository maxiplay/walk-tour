"""The tests for Roller shutter platforms."""
