"""The tests for Switch platforms."""
