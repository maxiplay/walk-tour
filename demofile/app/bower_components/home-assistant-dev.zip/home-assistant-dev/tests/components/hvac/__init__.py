"""The tests for hvac component."""
