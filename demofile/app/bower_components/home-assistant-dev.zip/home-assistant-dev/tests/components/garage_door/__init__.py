"""The tests for Garage door platforms."""
