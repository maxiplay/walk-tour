"""The tests for Light platforms."""
