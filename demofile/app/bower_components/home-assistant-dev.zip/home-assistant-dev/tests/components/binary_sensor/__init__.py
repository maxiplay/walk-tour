"""The tests for Binary sensor platforms."""
